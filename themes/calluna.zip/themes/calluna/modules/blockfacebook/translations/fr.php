<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockfacebook}calluna>blockfacebook_43d541d80b37ddb75cde3906b1ded452'] = 'Bloc Facebook like';
$_MODULE['<{blockfacebook}calluna>blockfacebook_e2887a32ddafab9926516d8cb29aab76'] = 'Affiche un bloc pour s\'abonner à votre page Facebook.';
$_MODULE['<{blockfacebook}calluna>blockfacebook_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise à jour';
$_MODULE['<{blockfacebook}calluna>blockfacebook_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockfacebook}calluna>blockfacebook_c98cf18081245e342d7929c117066f0b'] = 'Lien Facebook (mettez l\'adresse complète)';
$_MODULE['<{blockfacebook}calluna>blockfacebook_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockfacebook}calluna>blockfacebook_374fe11018588d3d27e630b2dffb7909'] = 'Suivez-nous sur Facebook';
$_MODULE['<{blockfacebook}calluna>preview_31fde7b05ac8952dacf4af8a704074ec'] = 'Visualisez';
$_MODULE['<{blockfacebook}calluna>preview_374fe11018588d3d27e630b2dffb7909'] = 'Suivez-nous sur Facebook';
