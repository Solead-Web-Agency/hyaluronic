<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksearch}calluna>blocksearch_e2ca130372651672ba285abd796412ed'] = 'Bloco pesquisa rápida';
$_MODULE['<{blocksearch}calluna>blocksearch_be305c865235f417d9b4d22fcdf9f1c5'] = 'Adiciona um campo de pesquisa rápida ao seu site.';
$_MODULE['<{blocksearch}calluna>blocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Pesquisar';
$_MODULE['<{blocksearch}calluna>blocksearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Pesquisar';
$_MODULE['<{blocksearch}calluna>blocksearch_ce1b00a24b52e74de46971b174d2aaa6'] = 'Procurar Produtos:';
$_MODULE['<{blocksearch}calluna>blocksearch_5f075ae3e1f9d0382bb8c4632991f96f'] = 'Ir';
