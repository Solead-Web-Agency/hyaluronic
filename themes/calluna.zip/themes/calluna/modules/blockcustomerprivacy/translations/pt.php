<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_e0de5a06213f21c55ca3283c009e0907'] = 'Bloco privacidade dos dados dos clientes';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_f192f208f0bc97af4c5213eee3e78793'] = 'Adiciona um bloco que apresenta uma mensagem sobre a privacidade dos dados dos clientes.';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_d71315851e7e67cbacf5101c5c4ab83d'] = 'Os dados pessoais que fornecer são usados para responder a questões, processar encomendas ou permitir o acesso a informações específicas.';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_d847e75da5489bbc525b6f6548d7f50a'] = 'Tem o direito de modificar e eliminar todas as informações pessoais encontradas na página \"A Minha Conta\".';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuração atualizada';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Se concordar com os termos da mensagem de Privacidade de Dados de Clientes, por favor, clique na caixa abaixo.';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_f4f70727dc34561dfde1a3c529b6205c'] = 'Definições';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_aafe06caae02aee29775402368a6d22c'] = 'Mensagem de privacidade dos dados de cliente:';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'A mensagem de privacidade de dados de clientes será exibida no formulário de criação de conta.';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Privacidade de dados dos clientes';
