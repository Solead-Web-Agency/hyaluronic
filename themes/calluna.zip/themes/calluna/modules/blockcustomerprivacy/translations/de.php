<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_e0de5a06213f21c55ca3283c009e0907'] = 'Block Kunden-Datenschutz';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_f192f208f0bc97af4c5213eee3e78793'] = 'Fügt einen Block hinzu, um Informationen zum Kunden-Datenschutz anzuzeigen.';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_d71315851e7e67cbacf5101c5c4ab83d'] = 'Ihre personenbezogenen Daten werden ausschließlich verwendet, um Ihre Anfragen zu beantworten, Ihre Aufträge zu bearbeiten oder Ihnen Zugang zu bestimmten Informationen zu verschaffen.';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_d847e75da5489bbc525b6f6548d7f50a'] = 'Sie können jederzeit Ihre persönlichen Angaben aktualisieren oder löschen - wählen Sie dazu bitte \"Mein Konto\".';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguration aktualisiert';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Bitte stimmen Sie den Datenschutzbedingungen zu, indem Sie auf das Kontrollkästchen unten klicken.';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_aafe06caae02aee29775402368a6d22c'] = 'Nachricht zum Kunden-Datenschutz';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Die Nachricht zum Kunden-Datenschutz wird auf dem Anmeldeformular angezeigt.';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockcustomerprivacy}calluna>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Kunden-Datenschutz';
