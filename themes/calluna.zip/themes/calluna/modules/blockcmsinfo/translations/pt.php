<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Bloco de informação CMS personalizado';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Adiciona blocos personalizados de informação  à sua loja.';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Ocorreu um erro ao tentar gravar.';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Novo bloco CMS personalizado';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Texto';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Voltar à lista';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_9d55fc80bbb875322aa67fd22fc98469'] = 'Associação de loja';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'N.º do bloco';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_9f82518d468b9fee614fcc92f76bb163'] = 'Loja';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Bloco de texto';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Adicionar novo';
