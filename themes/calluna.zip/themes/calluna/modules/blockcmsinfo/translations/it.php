<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Blocco informazioni CMS personalizzato';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Aggiungi blocchi delle informazioni personalizzati al tuo negozio.';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_86432715902fbaf53de469fed3fa6c53'] = 'Devi selezionare almeno un negozio.';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Errore durante il salvataggio.';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Nuovo blocco CMS personalizzato';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Testo';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Torna alla lista';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_9d55fc80bbb875322aa67fd22fc98469'] = 'Associazione negozi';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'ID blocco';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_9f82518d468b9fee614fcc92f76bb163'] = 'Negozio';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Sezione di testo';
$_MODULE['<{blockcmsinfo}calluna>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Aggiungi nuovo';
