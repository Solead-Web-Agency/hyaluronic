<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_b97d23f7cde011d190f39468e146425e'] = 'Блок Моя учетная запись в подвале';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_abdb95361b4c92488add0a5a37afabcb'] = 'Отображает блок со ссылками связанными с учетной записью пользователя.';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_ae9ec80afffec5a455fbf2361a06168a'] = 'Управление моей учетной записью покупателя';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Моя учетная запись';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_74ecd9234b2a42ca13e775193f391833'] = 'Мои заказы';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_5973e925605a501b18e48280f04f0347'] = 'Список моих возвратов товара';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_89080f0eedbd5491a93157930f1e45fc'] = 'Мои возвраты';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_9132bc7bac91dd4e1c453d4e96edf219'] = 'Мои кредитные квитанции';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Мои адреса';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_b4b80a59559e84e8497f746aac634674'] = 'Управление моими персональными данными';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_63b1ba91576576e6cf2da6fab7617e58'] = 'Моя личная информация';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_95d2137c196c7f84df5753ed78f18332'] = 'Мои купоны';
$_MODULE['<{blockmyaccountfooter}calluna>blockmyaccountfooter_c87aacf5673fada1108c9f809d354311'] = 'Выйти';
