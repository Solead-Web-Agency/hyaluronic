<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_fc02586aa99596947b184a01f43fb4ae'] = 'Blocco informazioni contatto';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_86458ae1631be34a6fcbf1a4584f5abe'] = 'Aggiungi un blocco per aggiungere informazioni su come contattare il negozio.';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configurazione aggiornata';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_c281f92b77ba329f692077d23636f5c9'] = 'Nome azienda';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_dd7bf230fde8d4836917806aff6a6b27'] = 'Indirizzo';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_1f8261d17452a959e013666c5df45e07'] = 'Numero di telefono';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_02d4482d332e1aef3437cd61c9bcc624'] = 'Contattaci';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_2e006b735fbd916d8ab26978ae6714d4'] = 'Tel';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_6a1e265f92087bb6dd18194833fe946b'] = 'Email:';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_e72dca5d5a8a4706a206f3225324bf44'] = 'Calluna';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_80a11d2a54a677f6fadd9c041c0d6b98'] = 'Negozio';
$_MODULE['<{blockcontactinfos}calluna>blockcontactinfos_f45d03c5d22af05b9b427c1bc94c606c'] = 'Scrivi il tuo testo qui su il tuo negozio ';
