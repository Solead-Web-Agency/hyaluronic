{*
* 2007-2014 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2014 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*}

<!-- Block permanent links module HEADER -->

<div class="header_links">

<ul id="header_links" class="hidden-phone">	
  
    <li>
    <a class="link-img-myaccount" href="{$link->getPageLink('my-account', true)}" title="{l s='my account' mod='blockpermanentlinks'}">
    
    <span class="link-label">{l s='my account' mod='blockpermanentlinks'}</span>
    </a>
    </li>
    
	<li>
    <a class="link-img-contact" href="{$link->getPageLink('contact', true)}" title="{l s='contact' mod='blockpermanentlinks'}">
    
    <span class="link-label">{l s='contact' mod='blockpermanentlinks'}</span>
    </a>
    </li>
    
    <li>
    <a class="link-img-wishlist" 	href="{$link->getModuleLink('blockwishlist', 'mywishlist', array(), true)|addslashes}" title="{l s='My wishlists' mod='blockwishlist'}">
    
    <span class="link-label">{l s='Wishlists' mod='blockpermanentlinks'}</span>
    </a>
    </li>

	
</ul>

</div>

<!-- /Block permanent links module HEADER -->
