<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_bedd646b07e65f588b06f275bd47be07'] = 'Advertentieblok';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_dc23a0e1424eda56d0700f7ebe628c78'] = 'Voegt een advertentieblok toe aan de geselecteerde delen van uw e-commerce website.';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_b15e7271053fe9dd22d80db100179085'] = 'Deze module moet gelinkt worden in een kolom en uw thema implementeert dit niet';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_070e16b4f77b90e802f789b5be583cfa'] = 'Fout opgetreden tijdens het verplaatsen van het geüploade bestand';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_254f642527b45bc260048e30704edb39'] = 'Configuratie';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_89ca5c48bbc6b7a648a5c1996767484c'] = 'Blokafbeelding';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_05177d68c546e5b754e39ae3ce211cc2'] = 'Afbeelding wordt weergegeven als 155 pixels bij 163 pixels.';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_9ce38727cff004a058021a6c7351a74a'] = 'Afbeelding link';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_b78a3223503896721cca1303f776159b'] = 'Aanspreektitel';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_c9cc8cce247e49bae79f15173ce97354'] = 'Opslaan';
