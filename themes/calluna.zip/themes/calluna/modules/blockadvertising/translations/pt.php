<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_070e16b4f77b90e802f789b5be583cfa'] = 'Erro de upload do ficheiro.';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_254f642527b45bc260048e30704edb39'] = 'Configuração';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_9ce38727cff004a058021a6c7351a74a'] = 'Link da imagem';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_b78a3223503896721cca1303f776159b'] = 'Título';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
