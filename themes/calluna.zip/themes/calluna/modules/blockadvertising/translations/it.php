<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_bedd646b07e65f588b06f275bd47be07'] = 'Blocco pubblicitario';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_dc23a0e1424eda56d0700f7ebe628c78'] = 'Aggiunge un blocco pubblicitario a determinate sezioni del tuo sito di e-commerce.';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_b15e7271053fe9dd22d80db100179085'] = 'Questo modulo ha bisogno di essere ancorato ad una colonna e il tuo tema non ne contiene';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_070e16b4f77b90e802f789b5be583cfa'] = 'Errore nel caricamento del file.';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_254f642527b45bc260048e30704edb39'] = 'Configurazione';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_89ca5c48bbc6b7a648a5c1996767484c'] = 'Immagine blocco';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_05177d68c546e5b754e39ae3ce211cc2'] = 'L\'immagine verrà visualizzata in risoluzione 155x163 pixel.';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_9ce38727cff004a058021a6c7351a74a'] = 'Link Immagine';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_b78a3223503896721cca1303f776159b'] = 'Titolo';
$_MODULE['<{blockadvertising}newparuresix>blockadvertising_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
