<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_f7c34fc4a48bc683445c1e7bbc245508'] = 'Block Neue Produkte';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_d3ee346c7f6560faa13622b6fef26f96'] = 'Zeigt einen Block mit neu hinzugefügten Artikeln an';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_1cd777247f2a6ed79534d4ace72d78ce'] = 'Sie müssen das Feld \"Anzuzeigende Artikel\" ausfüllen.';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_73293a024e644165e9bf48f270af63a0'] = 'Ungültige Anzahl';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_26986c3388870d4148b1b5375368a83d'] = 'Anzuzeigende Artikel';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_3ea7689283770958661c27c37275b89c'] = 'Anzahl der Artikel festlegen, die in diesem Block angezeigt werden sollen';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_85dd6b2059e1ff8fbefcc9cf6e240933'] = 'Anzahl der Tage, in denen der Artikel als \"NEU\" angesehen wird';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_24ff4e4d39bb7811f6bdf0c189462272'] = 'Block immer anzeigen';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_d68e7b860a7dba819fa1c75225c284b5'] = 'Block anzeigen, auch wenn kein Produkt verfügbar ist';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_home_0af0aac2e9f6bd1d5283eed39fe265cc'] = 'Aktuell keine neuen Artikel.';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_9ff0635f5737513b1a6f559ac2bff745'] = 'Neue Produkte';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_43340e6cc4e88197d57f8d6d5ea50a46'] = 'Weiterlesen ';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_60efcc704ef1456678f77eb9ee20847b'] = 'Alle neuen Produkte ';
$_MODULE['<{blocknewproducts}calluna>blocknewproducts_18cc24fb12f89c839ab890f8188febe8'] = 'Neue Produkte ermöglichen nicht zu diesem Zeitpunkt. ';
$_MODULE['<{blocknewproducts}calluna>tab_a0d0ebc37673b9ea77dd7c1a02160e2d'] = 'Neu eingetroffen ';
