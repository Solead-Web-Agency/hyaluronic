<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksharefb}calluna>blocksharefb_4b7fc122c9f0d85fd4a0db387f64248c'] = 'Facebook sharing block';
$_MODULE['<{blocksharefb}calluna>blocksharefb_b28cc547a11f23d941e3e6b615acd154'] = 'Allows customers to share your products or content on Facebook.';
$_MODULE['<{blocksharefb}calluna>blocksharefb_353005a70db1e1dac3aadedec7596bd7'] = 'Share on Facebook!';
