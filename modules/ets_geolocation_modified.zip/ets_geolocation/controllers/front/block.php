<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class Ets_geolocationBlockModuleFrontController extends ModuleFrontController
{
    public function __construct()
    {
        parent::__construct();
        $this->template = ($this->module->is17 ? 'module:ets_geolocation/views/templates/front/' : '') . 'block.tpl';
    }

    public function initContent()
    {
        parent::initContent();
        $this->context->smarty->assign([
            'msg' => Configuration::get('ETS_GEO_BLOG_MSG', $this->context->language->id),
        ]);
        $content = $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/front/block.tpl');
        exit($content);
    }
}
