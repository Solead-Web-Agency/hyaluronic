<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

/**
 * Class FrontController
 *
 * @since 1.1.8
 */
class FrontController extends FrontControllerCore
{
    /**
     * Geolocation management
     *
     * @param Country $default_country
     *
     * @return Country|false
     */
    protected function geolocationManagement($default_country)
    {
        if (in_array(Tools::getRemoteAddr(), ['127.0.0.1', '::1'])) {
            return false;
        }
        if (version_compare(_PS_VERSION_, '1.7', '>') || !Module::isEnabled('ets_geolocation')) {
            return parent::geolocationManagement($default_country);
        }
        /** @var \Ets_geolocation $module */
        $module = Module::getInstanceByName('ets_geolocation');
        if (!$module) {
            return parent::geolocationManagement($default_country);
        }
        if ($module->isGeoLiteCityAvailable() && Configuration::get('PS_GEOLOCATION_ENABLED')) {
            if (!isset($this->context->cookie->iso_code_country) || (isset($this->context->cookie->iso_code_country) && !in_array(strtoupper($this->context->cookie->iso_code_country), explode(';', Configuration::get('PS_ALLOWED_COUNTRIES'))))) {
                if (!class_exists('\GeoIp2\Database\Reader')) {
                    require_once _PS_MODULE_DIR_ . 'ets_geolocation/vendor/geoip2/autoload.php';
                }
                $reader = new GeoIp2\Database\Reader($module->getGeoLiteDbFilePath());

                try {
                    $record = $reader->city($module->getRemoteAddr());
                } catch (\GeoIp2\Exception\AddressNotFoundException $e) {
                    $record = null;
                }

                if (is_object($record) && Validate::isLanguageIsoCode($record->country->isoCode) && ($geoIdCountry = (int) Country::getByIso(strtoupper($record->country->isoCode))) != 0) {
                    if (!in_array(strtoupper($record->country->isoCode), explode(';', Configuration::get('PS_ALLOWED_COUNTRIES'))) && !FrontController::isInWhitelistForGeolocation()) {
                        if (Configuration::get('PS_GEOLOCATION_BEHAVIOR') == _PS_GEOLOCATION_NO_CATALOG_) {
                            $this->restrictedCountry = true;
                        } elseif (Configuration::get('PS_GEOLOCATION_BEHAVIOR') == _PS_GEOLOCATION_NO_ORDER_) {
                            $this->context->smarty->assign([
                                'restricted_country_mode' => true,
                                'geolocation_country' => (new \Country($geoIdCountry, Configuration::get('PS_LANG_DEFAULT')))->name,
                            ]);
                        }
                    } else {
                        $has_been_set = !isset($this->context->cookie->iso_code_country);
                        $this->context->cookie->iso_code_country = strtoupper($record->country->isoCode);
                    }
                }
            }

            if (isset($this->context->cookie->iso_code_country) && $this->context->cookie->iso_code_country && !Validate::isLanguageIsoCode($this->context->cookie->iso_code_country)) {
                $this->context->cookie->iso_code_country = Country::getIsoById(Configuration::get('PS_COUNTRY_DEFAULT'));
            }

            if (isset($this->context->cookie->iso_code_country) && ($id_country = (int) Country::getByIso(strtoupper($this->context->cookie->iso_code_country)))) {
                /* Update defaultCountry */
                if ($default_country->iso_code != $this->context->cookie->iso_code_country) {
                    $default_country = new Country($id_country);
                }
                if (isset($has_been_set) && $has_been_set) {
                    $this->context->cookie->id_currency = (int) ($default_country->id_currency ? (int) $default_country->id_currency : (int) Configuration::get('PS_CURRENCY_DEFAULT'));
                }

                return $default_country;
            }

            if (Configuration::get('PS_GEOLOCATION_NA_BEHAVIOR') == _PS_GEOLOCATION_NO_CATALOG_ && !FrontController::isInWhitelistForGeolocation()) {
                $this->restrictedCountry = true;
            } elseif (Configuration::get('PS_GEOLOCATION_NA_BEHAVIOR') == _PS_GEOLOCATION_NO_ORDER_ && !FrontController::isInWhitelistForGeolocation()) {
                $this->context->smarty->assign([
                    'restricted_country_mode' => true,
                    'geolocation_country' => isset($record->country_name) && $record->country_name ? $record->country_name : 'Undefined',
                ]);
            }
        }

        return false;
    }
}
