<?php
/**
 *  Module made by Nukium
 *
 *  @author    Nukium
 *  @copyright 2021 Nukium SAS
 *  @license   All rights reserved
 *
 * ███    ██ ██    ██ ██   ██ ██ ██    ██ ███    ███
 * ████   ██ ██    ██ ██  ██  ██ ██    ██ ████  ████
 * ██ ██  ██ ██    ██ █████   ██ ██    ██ ██ ████ ██
 * ██  ██ ██ ██    ██ ██  ██  ██ ██    ██ ██  ██  ██
 * ██   ████  ██████  ██   ██ ██  ██████  ██      ██
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

if (!class_exists('GlsController')) {
    require_once dirname(__FILE__) . '/../../classes/GlsController.php';
}

class NkmGlsCheckoutModuleFrontController extends ModuleFrontController
{
    const L_SPECIFIC = 'checkout';

    public function __construct()
    {
        $this->module = 'nkmgls';
        parent::__construct();
    }


    public function displayAjaxSavePhoneMobile()
    {
        $cart = $this->context->cart;
        $return = array(
            'result' => false,
            'message' => ''
        );

        $phone_mobile = Tools::getValue('gls_customer_mobile');
        $id_carrier = Tools::getValue('id_carrier');
        $is_relay = Tools::getValue('is_relay');

        if ($cart && !empty($id_carrier)) {
            $customer_address = new Address($cart->id_address_delivery);
            $customer_country_iso = '';
            if ($customer_address) {
                $customer_country_iso = Country::getIsoById($customer_address->id_country);
            }
            $gls_product = $this->getGlsProductCode((int) $id_carrier, $customer_country_iso);

            $query = new DbQuery();
            $query->select('c.*')
                ->from('gls_cart_carrier', 'c')
                ->where('c.`id_customer` = ' . (int) $cart->id_customer)
                ->where('c.`id_cart` = ' . (int) $cart->id);

            if (Db::getInstance()->getRow($query)) {
                $sql = 'UPDATE ' . _DB_PREFIX_ . 'gls_cart_carrier SET `customer_phone_mobile`=\'' . pSQL($phone_mobile) . '\', `id_carrier`=' . (int) $id_carrier . ', `gls_product`=\'' . pSQL($gls_product) . '\'';
                if (! $is_relay) {
                    $sql .= ',`parcel_shop_id` = NULL, `name` = NULL, `address1` = NULL, `address2` = NULL, `postcode` = NULL,
                        `city` = NULL, `phone` = NULL, `phone_mobile` = NULL, `id_country` = NULL, `parcel_shop_working_day` = NULL';
                }
                $sql .= ' WHERE `id_customer`=' . (int) $cart->id_customer . ' AND `id_cart`=' . (int) $cart->id;

                if (Db::getInstance()->Execute($sql)) {
                    $return['result'] = true;
                } else {
                    $return['message'] = $this->module->l('Unexpected error occurred.', self::L_SPECIFIC);
                }
            } else {
                if (Db::getInstance()->Execute('INSERT INTO ' . _DB_PREFIX_ . 'gls_cart_carrier
                    (`id_customer`, `id_cart`, `id_carrier`, `gls_product`, `customer_phone_mobile`)
                    VALUES (' . (int) $cart->id_customer . ', ' . (int) $cart->id . ', ' . (int) $id_carrier . ', \'' . pSQL($gls_product) . '\', \'' . pSQL($phone_mobile) . '\')')) {
                    $return['result'] = true;
                } else {
                    $return['message'] = $this->module->l('Unexpected error occurred.', self::L_SPECIFIC);
                }
            }
        }

        header('Content-Type: application/json');
        $this->ajaxDie(json_encode($return));
    }


    public function displayAjaxSelectRelayPoint()
    {
        $return = array(
            'result' => false,
            'message' => ''
        );

        $gls_relay_id = Tools::getValue('glsrelayid');
        $module_config = $this->module->getConfigFormValues();

        $gls = new GlsController($module_config);
        $relay_detail = $gls->getRelayDetail($gls_relay_id);


        if ($relay_detail) {
            $cart = $this->context->cart;
            $id_country = Country::getByIso($relay_detail['Country']);

            $gls_product = $this->getGlsProductCode(Configuration::get('GLS_GLSRELAIS_ID', (int) $cart->id_carrier, $this->context->shop->id_shop_group, $this->context->shop->id), $relay_detail['Country']);

            Db::getInstance()->delete('gls_cart_carrier', 'id_cart = "' . pSQL($cart->id) . '"');
            $sql = 'INSERT IGNORE INTO ' . _DB_PREFIX_ . "gls_cart_carrier VALUES (
                '" . (int) $cart->id . "',
                '" . (int) $cart->id_customer . "',
                '" . (int) Configuration::get('GLS_GLSRELAIS_ID', (int) $cart->id_carrier, $this->context->shop->id_shop_group, $this->context->shop->id) . "',
                '" . pSQL($gls_product) . "',
                '" . pSQL(Tools::getValue('glsrelayid')) . "',
                '" . pSQL($relay_detail['Name1']) . "',
                '" . pSQL($relay_detail['Street1']) . "',
                '" . pSQL($relay_detail['Street2']) . "',
                '" . pSQL($relay_detail['ZipCode']) . "',
                '" . pSQL($relay_detail['City']) . "',
                '" . pSQL($relay_detail['Phone']) . "',
                '" . pSQL($relay_detail['Mobile']) . "',
                '" . pSQL(Tools::getValue('gls_customer_mobile', '')) . "',
                '" . (int) $id_country . "',
                '" . pSQL(json_encode($relay_detail['GLSWorkingDay'])) . "'
            )";

            if (! Db::getInstance()->Execute($sql)) {
                $return['message'] = $this->module->l('Unexpected error occurred while saving delivery informations.', self::L_SPECIFIC);
            } else {
                $return['result'] = true;
            }
        } else {
            $return['message'] = $this->module->l('GLS Relais informations not found. Please select another one.', self::L_SPECIFIC);
        }

        header('Content-Type: application/json');
        $this->ajaxDie(json_encode($return));
    }


    public function getGlsProductCode($_id_carrier, $_country = 'FR')
    {
        if (! empty($_id_carrier) && is_numeric($_id_carrier)) {
            if ($_id_carrier == Configuration::get('GLS_GLSCHEZVOUS_ID', null, $this->context->shop->id_shop_group, $this->context->shop->id) && ($_country == 'FR' || $_country == 'COS')) {
                return '02';
            } elseif ($_id_carrier == Configuration::get('GLS_GLSCHEZVOUS_ID', null, $this->context->shop->id_shop_group, $this->context->shop->id) && $_country != 'FR' && $_country != 'COS') {
                return '01';
            } elseif ($_id_carrier == Configuration::get('GLS_GLSCHEZVOUSPLUS_ID', null, $this->context->shop->id_shop_group, $this->context->shop->id) && ($_country == 'FR' || $_country == 'COS')) {
                return '18';
            } elseif ($_id_carrier == Configuration::get('GLS_GLSCHEZVOUSPLUS_ID', null, $this->context->shop->id_shop_group, $this->context->shop->id) && $_country != 'FR' && $_country != 'COS') {
                return '19';
            } elseif ($_id_carrier == Configuration::get('GLS_GLSRELAIS_ID', null, $this->context->shop->id_shop_group, $this->context->shop->id)) {
                return '17';
            } elseif ($_id_carrier == Configuration::get('GLS_GLS13H_ID', null, $this->context->shop->id_shop_group, $this->context->shop->id)) {
                return '16';
            }
        }

        return false;
    }


    public function displayAjaxSearchRelay()
    {
        $module_config = $this->module->getConfigFormValues();
        $return = array(
            'result' => false,
            'message' => '',
            'point_relay_tpl' => '',
            'point_relay_maps' => array()
        );

        $postcode = '';
        $city = '';

        $search = Tools::getValue('search');
        $search_tmp = explode(' ', $search);
        foreach ($search_tmp as $value) {
            if (is_numeric($value) && Tools::strlen($value) === 5) {
                $postcode = $value;
            } else {
                $city .= $value;
            }
        }

        if (! empty($postcode)) {
            $gls = new GlsController($module_config);

            $result = $gls->searchRelay($postcode, $city);

            if (isset($result->exitCode->ErrorCode)) {
                if ((int) $result->exitCode->ErrorCode == 998 || (int) $result->exitCode->ErrorCode == 999) {
                    $return['message'] = $this->module->l('We haven\'t found any GLS Relais in your delivery area. Please expand your search.', self::L_SPECIFIC);
                } elseif ((int) $result->exitCode->ErrorCode == 0) {
                    $relay_points = $result->SearchResults;

                    if ($module_config['GLS_GLSRELAIS_XL_ONLY']) {
                        foreach ($relay_points as $key => $value) {
                            if (! empty($value->Parcelshop->Address->Name1) && Tools::substr($value->Parcelshop->Address->Name1, - 2) != 'XL') {
                                unset($relay_points[$key]);
                            }
                        }
                        $relay_points = array_values($relay_points);
                    }

                    if (count($relay_points) <= 0) {
                        $return['message'] = $this->module->l('We haven\'t found any GLS Relais in your delivery area. Please expand your search.', self::L_SPECIFIC);
                    } else {
                        $this->context->smarty->assign(array(
                            'trans_days' => array(
                                '0' => $this->module->l('Monday', self::L_SPECIFIC),
                                '1' => $this->module->l('Tuesday', self::L_SPECIFIC),
                                '2' => $this->module->l('Wednesday', self::L_SPECIFIC),
                                '3' => $this->module->l('Thursday', self::L_SPECIFIC),
                                '4' => $this->module->l('Friday', self::L_SPECIFIC),
                                '5' => $this->module->l('Saturday', self::L_SPECIFIC),
                                '6' => $this->module->l('Sunday', self::L_SPECIFIC)
                            ),
                            'relay_points' => $relay_points,
                            'only_xl' => $module_config['GLS_GLSRELAIS_XL_ONLY']
                        ));
                        $return['point_relay_tpl'] = $this->context->smarty->fetch('module:' . $this->module->name . '/views/templates/front/search_result.tpl');
                        $return['result'] = true;
                    }
                } else {
                    $return['message'] = $result->exitCode->ErrorCode . ': ' . $result->exitCode->ErrorDscr;
                }
            } else {
                $return['message'] = $this->module->l('Unexpected error occured while searching GLS Relais.', self::L_SPECIFIC);
            }
        } else {
            $return['message'] = $this->module->l('Please fill in a valid postcode.', self::L_SPECIFIC);
        }

        header('Content-Type: application/json');
        $this->ajaxDie(json_encode($return));
    }
}
