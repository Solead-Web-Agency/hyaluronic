<?php
class ProductController extends ProductControllerCore
{
    /*
    * module: ets_seo
    * date: 2022-01-17 18:57:39
    * version: 2.4.2
    */
    public function getTemplateVarPage()
    {
        $page =  parent::getTemplateVarPage();
        if (isset($page['meta']['title'])){
            $moduleSeo = Module::getInstanceByName('ets_seo');
            if ($moduleSeo){
                $price = $this->getPriceProduct();
                $discount_price = $this->getPriceProduct(true);
                $brand = $this->getBrandName();
                $desc = $this->product->description_short;
                $pageTitle = $moduleSeo->formatSeoMeta($this->product->name, array('post_title' => '', 'is_title' => true, 'category' => $this->category->name, 'price' => $price, 'description' => $desc, 'brand' => $brand, 'discount_price' => $discount_price), 'product');
                $page['meta']['title'] = $moduleSeo->formatSeoMeta($page['meta']['title'], array('post_title' => $pageTitle, 'is_title' => true, 'category' => $this->category->name, 'price' => $price, 'description' => $desc, 'brand' => $brand, 'discount_price' => $discount_price), 'product');
            }
        }
        return $page;
    }
    /*
    * module: ets_seo
    * date: 2022-01-17 18:57:39
    * version: 2.4.2
    */
    public function getPriceProduct($getDiscount = false)
    {
        $id_customer = ($this->context->customer->id) ? (int)($this->context->customer->id) : 0;
        $id_group = null;
        if ($id_customer) {
            $id_group = Customer::getDefaultGroupId((int)$id_customer);
        }
        if (!$id_group) {
            $id_group = (int)Group::getCurrent()->id;
        }
        $group = new Group($id_group);
        if ($group->price_display_method)
            $tax = false;
        else
            $tax = true;
        if ($getDiscount)
            return Tools::displayPrice($this->product->getPrice($tax));
        return Tools::displayPrice($this->product->getPriceWithoutReduct(!$tax));
    }
    /*
    * module: ets_seo
    * date: 2022-01-17 18:57:39
    * version: 2.4.2
    */
    public function getBrandName()
    {
        if($this->product->id_manufacturer && ($manuf = new Manufacturer($this->product->id_manufacturer, $this->context->language->id)) && $manuf->id){
            return $manuf->name;
        }
        return '';
    }
    /*
    * module: groupinc
    * date: 2024-01-28 14:02:32
    * version: 1.6.2
    */
    protected function assignAttributesGroups($product_for_template = null)
    {
        if (!Module::isEnabled('groupinc')) {
            return parent::assignAttributesGroups($product_for_template);
        }
        $colors = array();
        $groups = array();
        $this->combinations = array();
        $attributes_groups = $this->product->getAttributesGroups($this->context->language->id);
        if (is_array($attributes_groups) && $attributes_groups) {
            $combination_images = $this->product->getCombinationImages($this->context->language->id);
            $combination_prices_set = array();
            foreach ($attributes_groups as $k => $row) {
                if (isset($row['is_color_group']) && $row['is_color_group'] && (isset($row['attribute_color']) && $row['attribute_color']) || (file_exists(_PS_COL_IMG_DIR_.$row['id_attribute'].'.jpg'))) {
                    $colors[$row['id_attribute']]['value'] = $row['attribute_color'];
                    $colors[$row['id_attribute']]['name'] = $row['attribute_name'];
                    if (!isset($colors[$row['id_attribute']]['attributes_quantity'])) {
                        $colors[$row['id_attribute']]['attributes_quantity'] = 0;
                    }
                    $colors[$row['id_attribute']]['attributes_quantity'] += (int) $row['quantity'];
                }
                if (!isset($groups[$row['id_attribute_group']])) {
                    $groups[$row['id_attribute_group']] = array(
                        'group_name' => $row['group_name'],
                        'name' => $row['public_group_name'],
                        'group_type' => $row['group_type'],
                        'default' => -1,
                    );
                }
                $groups[$row['id_attribute_group']]['attributes'][$row['id_attribute']] = array(
                    'name' => $row['attribute_name'],
                    'html_color_code' => $row['attribute_color'],
                    'texture' => (@filemtime(_PS_COL_IMG_DIR_.$row['id_attribute'].'.jpg')) ? _THEME_COL_DIR_.$row['id_attribute'].'.jpg' : '',
                    'selected' => (isset($product_for_template['attributes'][$row['id_attribute_group']]['id_attribute']) && $product_for_template['attributes'][$row['id_attribute_group']]['id_attribute'] == $row['id_attribute']) ? true : false,
                );
                if ($row['default_on'] && $groups[$row['id_attribute_group']]['default'] == -1) {
                    $groups[$row['id_attribute_group']]['default'] = (int) $row['id_attribute'];
                }
                if (!isset($groups[$row['id_attribute_group']]['attributes_quantity'][$row['id_attribute']])) {
                    $groups[$row['id_attribute_group']]['attributes_quantity'][$row['id_attribute']] = 0;
                }
                $groups[$row['id_attribute_group']]['attributes_quantity'][$row['id_attribute']] += (int) $row['quantity'];
                $this->combinations[$row['id_product_attribute']]['attributes_values'][$row['id_attribute_group']] = $row['attribute_name'];
                $this->combinations[$row['id_product_attribute']]['attributes'][] = (int) $row['id_attribute'];
                $this->combinations[$row['id_product_attribute']]['price'] = (float) $row['price'];
                if (!isset($combination_prices_set[(int) $row['id_product_attribute']])) {
                    $combination_specific_price = null;
                    Product::getPriceStatic((int) $this->product->id, false, $row['id_product_attribute'], 6, null, false, true, 1, false, null, null, null, $combination_specific_price);
                    $combination_prices_set[(int) $row['id_product_attribute']] = true;
                    $this->combinations[$row['id_product_attribute']]['specific_price'] = $combination_specific_price;
                }
                if (Module::isEnabled('groupinc')) {
                    $id_customer = $this->context->cart->id_customer;
                    include_once(_PS_MODULE_DIR_.'groupinc/classes/GroupincConfiguration.php');
                    $groupinc = new GroupincConfiguration();
                    $id_shop = $this->context->cart->id_shop;
                    $id_currency = $this->context->cart->id_currency;
                    $id_address_delivery = $this->context->cart->id_address_delivery;
                    $address = new Address($id_address_delivery);
                    $id_country = $address->id_country;
                    if ($id_country == 0) {
                        $id_country = $this->context->country->id;
                    }
                    $id_state = $address->id_state;
                    $id_product = $this->product->id;
                    $onsaleconf = $groupinc->getGIConfigurations($id_shop, $id_product, $id_customer, $id_country, $id_state, $id_currency, $this->context->language->id, true, true, $row['id_product_attribute'], false, true);
                    if (!empty($onsaleconf)) {
                        $this->combinations[$row['id_product_attribute']]['on_sale'] = 1;
                        $this->combinations[$row['id_product_attribute']]['id_attribute'] = $row['id_attribute'];
                    }
                    $tax_manager = TaxManagerFactory::getManager($address, Product::getIdTaxRulesGroupByIdProduct((int)$id_product, $this->context));
                    $ptc = $tax_manager->getTaxCalculator();
                    $product = new Product($id_product);
                    $product_price_without_tax = $product->price;
                    $product_price_with_tax = $ptc->addTaxes($product_price_without_tax);
                    $configs_qd = $groupinc->getGIConfigurations($id_shop, $id_product, $id_customer, $id_country, $id_state, $id_currency, $this->context->language->id, false, true, 0, true);
                    if (!empty($configs_qd)) {
                        $qds = $groupinc->getQuantityDiscounts($configs_qd, $id_product, false, $product_price_with_tax, $product_price_without_tax, $ptc);
                        if (!empty($qds)) {
                            $this->combinations[$row['id_product_attribute']]['quantities'] = 1;
                            foreach ($qds as $c) {
                                if ((int)$c['id_product_attribute'] == (int)$row['id_product_attribute'] || (int)$c['id_product_attribute'] == 0) {
                                    $this->combinations[$row['id_product_attribute']]['on_sale'] = 1;
                                    $this->combinations[$row['id_product_attribute']]['id_attribute'] = $row['id_attribute'];
                                    if ($this->combinations[$row['id_product_attribute']]['quantities'] > 1 && $c['from_quantity'] < $this->combinations[$row['id_product_attribute']]['quantities']) {
                                        $this->combinations[$row['id_product_attribute']]['quantities'] = $c['from_quantity'];
                                    } else if ($this->combinations[$row['id_product_attribute']]['quantities'] == 1) {
                                        $this->combinations[$row['id_product_attribute']]['quantities'] = $c['from_quantity'];
                                    }
                                }
                            }
                        }
                    }
                }
                $this->combinations[$row['id_product_attribute']]['ecotax'] = (float) $row['ecotax'];
                $this->combinations[$row['id_product_attribute']]['weight'] = (float) $row['weight'];
                $this->combinations[$row['id_product_attribute']]['quantity'] = (int) $row['quantity'];
                $this->combinations[$row['id_product_attribute']]['reference'] = $row['reference'];
                $this->combinations[$row['id_product_attribute']]['unit_impact'] = $row['unit_price_impact'];
                $this->combinations[$row['id_product_attribute']]['minimal_quantity'] = $row['minimal_quantity'];
                if ($row['available_date'] != '0000-00-00' && Validate::isDate($row['available_date'])) {
                    $this->combinations[$row['id_product_attribute']]['available_date'] = $row['available_date'];
                    $this->combinations[$row['id_product_attribute']]['date_formatted'] = Tools::displayDate($row['available_date']);
                } else {
                    $this->combinations[$row['id_product_attribute']]['available_date'] = $this->combinations[$row['id_product_attribute']]['date_formatted'] = '';
                }
                if (!isset($combination_images[$row['id_product_attribute']][0]['id_image'])) {
                    $this->combinations[$row['id_product_attribute']]['id_image'] = -1;
                } else {
                    $this->combinations[$row['id_product_attribute']]['id_image'] = $id_image = (int) $combination_images[$row['id_product_attribute']][0]['id_image'];
                    if ($row['default_on']) {
                        foreach ($this->context->smarty->tpl_vars['product']->value['images'] as $image) {
                            if ($image['cover'] == 1) {
                                $current_cover = $image;
                            }
                        }
                        if (!isset($current_cover)) {
                            $current_cover = array_values($this->context->smarty->tpl_vars['product']->value['images'])[0];
                        }
                        if (is_array($combination_images[$row['id_product_attribute']])) {
                            foreach ($combination_images[$row['id_product_attribute']] as $tmp) {
                                if ($tmp['id_image'] == $current_cover['id_image']) {
                                    $this->combinations[$row['id_product_attribute']]['id_image'] = $id_image = (int) $tmp['id_image'];
                                    break;
                                }
                            }
                        }
                        if ($id_image > 0) {
                            if (isset($this->context->smarty->tpl_vars['images']->value)) {
                                $product_images = $this->context->smarty->tpl_vars['images']->value;
                            }
                            if (isset($product_images) && is_array($product_images) && isset($product_images[$id_image])) {
                                $product_images[$id_image]['cover'] = 1;
                                $this->context->smarty->assign('mainImage', $product_images[$id_image]);
                                if (count($product_images)) {
                                    $this->context->smarty->assign('images', $product_images);
                                }
                            }
                            $cover = $current_cover;
                            if (isset($cover) && is_array($cover) && isset($product_images) && is_array($product_images)) {
                                $product_images[$cover['id_image']]['cover'] = 0;
                                if (isset($product_images[$id_image])) {
                                    $cover = $product_images[$id_image];
                                }
                                $cover['id_image'] = (Configuration::get('PS_LEGACY_IMAGES') ? ($this->product->id.'-'.$id_image) : (int) $id_image);
                                $cover['id_image_only'] = (int) $id_image;
                                $this->context->smarty->assign('cover', $cover);
                            }
                        }
                    }
                }
            }
            $current_selected_attributes = array();
            $count = 0;
            foreach ($groups as &$group) {
                $count++;
                if ($count > 1) {
                    $id_attributes = Db::getInstance()->executeS('SELECT `id_attribute` FROM `'._DB_PREFIX_.'product_attribute_combination` pac2
                        WHERE `id_product_attribute` IN (
                            SELECT pac.`id_product_attribute`
                                FROM `'._DB_PREFIX_.'product_attribute_combination` pac
                                INNER JOIN `'._DB_PREFIX_.'product_attribute` pa ON pa.id_product_attribute = pac.id_product_attribute
                                WHERE id_product = '.$this->product->id.' AND id_attribute IN ('.implode(',', array_map('intval', $current_selected_attributes)).')
                                GROUP BY id_product_attribute
                                HAVING COUNT(id_product) = '.count($current_selected_attributes).'
                        ) AND id_attribute NOT IN ('.implode(',', array_map('intval', $current_selected_attributes)).')');
                    foreach ($id_attributes as $k => $row) {
                        $id_attributes[$k] = (int)$row['id_attribute'];
                    }
                    foreach ($group['attributes'] as $key => $attribute) {
                        if (!in_array((int)$key, $id_attributes)) {
                            unset($group['attributes'][$key]);
                            unset($group['attributes_quantity'][$key]);
                        }
                    }
                }
                $index = 0;
                $current_selected_attribute = 0;
                foreach ($group['attributes'] as $key => $attribute) {
                    if ($index === 0) {
                        $current_selected_attribute = $key;
                    }
                    if ($attribute['selected']) {
                        $current_selected_attribute = $key;
                        break;
                    }
                }
                if ($current_selected_attribute > 0) {
                    $current_selected_attributes[] = $current_selected_attribute;
                }
            }
            if (!Product::isAvailableWhenOutOfStock($this->product->out_of_stock) && Configuration::get('PS_DISP_UNAVAILABLE_ATTR') == 0) {
                foreach ($groups as &$group) {
                    foreach ($group['attributes_quantity'] as $key => &$quantity) {
                        if ($quantity <= 0) {
                            unset($group['attributes'][$key]);
                        }
                    }
                }
                foreach ($colors as $key => $color) {
                    if ($color['attributes_quantity'] <= 0) {
                        unset($colors[$key]);
                    }
                }
            }
            foreach ($this->combinations as $id_product_attribute => $comb) {
                $attribute_list = '';
                foreach ($comb['attributes'] as $id_attribute) {
                    $attribute_list .= '\''.(int) $id_attribute.'\',';
                }
                $attribute_list = rtrim($attribute_list, ',');
                $this->combinations[$id_product_attribute]['list'] = $attribute_list;
            }
            $this->context->smarty->assign(array(
                'groups' => $groups,
                'colors' => (count($colors)) ? $colors : false,
                'combinations' => $this->combinations,
                'combinationImages' => $combination_images,
            ));
        } else {
            $this->context->smarty->assign(array(
                'groups' => array(),
                'colors' => false,
                'combinations' => array(),
                'combinationImages' => array(),
            ));
        }
    }
    /*
    * module: groupinc
    * date: 2024-01-28 14:02:32
    * version: 1.6.2
    */
    public function initContent()
    {
        parent::initContent();
        if (Module::isEnabled('groupinc')) {
            include_once(_PS_MODULE_DIR_.'groupinc/classes/GroupincConfiguration.php');
            $this->product = GroupincConfiguration::changeProductProperties($this->product);
        }
    }
    /*
    * module: groupinc
    * date: 2024-01-28 14:02:32
    * version: 1.6.2
    */
    protected function formatQuantityDiscounts($specific_prices, $price, $tax_rate, $ecotax_amount)
    {
        $priceFormatter = new PrestaShop\PrestaShop\Adapter\Product\PriceFormatter();
        if (!empty($specific_prices[0]['price_groupinc'])) {
            $price_groupinc = $specific_prices[0]['price_groupinc'] * (1 + $tax_rate / 100);
            $price = $price_groupinc;
        }
        foreach ($specific_prices as $key => &$row) {
            $row['quantity'] = &$row['from_quantity'];
            if ($row['price'] >= 0) {
                $currentPriceDefaultCurrency = (!$row['reduction_tax'] ? $row['price'] : $row['price'] * (1 + $tax_rate / 100)) + (float) $ecotax_amount;
                $row['id_currency'];
                $currentPriceCurrentCurrency = Tools::convertPrice($currentPriceDefaultCurrency, $this->context->currency, true, $this->context);
                if ($row['reduction_type'] == 'amount') {
                    $currentPriceCurrentCurrency -= ($row['reduction_tax'] ? $row['reduction'] : $row['reduction'] / (1 + $tax_rate / 100));
                    $row['reduction_with_tax'] = $row['reduction_tax'] ? $row['reduction'] : $row['reduction'] / (1 + $tax_rate / 100);
                } else {
                    $currentPriceCurrentCurrency *= 1 - $row['reduction'];
                }
                $row['real_value'] = $price > 0 ? $price - $currentPriceCurrentCurrency : $currentPriceCurrentCurrency;
                $discountPrice = $price - $row['real_value'];
                if (Configuration::get('PS_DISPLAY_DISCOUNT_PRICE')) {
                    if ($row['reduction_tax'] == 0 && !$row['price']) {
                        $row['discount'] = $priceFormatter->format($price - ($price * $row['reduction_with_tax']));
                    } else {
                        $row['discount'] = $priceFormatter->format($price - $row['real_value']);
                    }
                } else {
                    $row['discount'] = $priceFormatter->format($row['real_value']);
                }
            } else {
                if ($row['reduction_type'] == 'amount') {
                    if (Product::$_taxCalculationMethod == PS_TAX_INC) {
                        $row['real_value'] = $row['reduction_tax'] == 1 ? $row['reduction'] : $row['reduction'] * (1 + $tax_rate / 100);
                    } else {
                        $row['real_value'] = $row['reduction_tax'] == 0 ? $row['reduction'] : $row['reduction'] / (1 + $tax_rate / 100);
                    }
                    $row['reduction_with_tax'] = $row['reduction_tax'] ? $row['reduction'] : $row['reduction'] + ($row['reduction'] * $tax_rate) / 100;
                    $discountPrice = $price - $row['real_value'];
                    if (Configuration::get('PS_DISPLAY_DISCOUNT_PRICE')) {
                        if ($row['reduction_tax'] == 0 && !$row['price']) {
                            $row['discount'] = $priceFormatter->format($price - ($price * $row['reduction_with_tax']));
                        } else {
                            $row['discount'] = $priceFormatter->format($price - $row['real_value']);
                        }
                    } else {
                        $row['discount'] = $priceFormatter->format($row['real_value']);
                    }
                } else {
                    $row['real_value'] = $row['reduction'] * 100;
                    $discountPrice = $price - $price * $row['reduction'];
                    if (Configuration::get('PS_DISPLAY_DISCOUNT_PRICE')) {
                        if ($row['reduction_tax'] == 0) {
                            $row['discount'] = $priceFormatter->format($price - ($price * $row['reduction_with_tax']));
                        } else {
                            $row['discount'] = $priceFormatter->format($price - ($price * $row['reduction']));
                        }
                    } else {
                        $row['discount'] = $row['real_value'] . '%';
                    }
                }
            }
            $pc = new ProductCore($row['id_product']);
            $row['save'] = $priceFormatter->format((($price * $row['quantity']) - ($discountPrice * $row['quantity'])));
            $row['nextQuantity'] = (isset($specific_prices[$key + 1]) ? (int) $specific_prices[$key + 1]['from_quantity'] : -1);
        }
        return $specific_prices;
    }
}