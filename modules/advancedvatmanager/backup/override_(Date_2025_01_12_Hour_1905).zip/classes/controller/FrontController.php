<?php
/**
 * Class FrontController
 *
 * @since 1.1.8
 */
class FrontController extends FrontControllerCore
{
}
