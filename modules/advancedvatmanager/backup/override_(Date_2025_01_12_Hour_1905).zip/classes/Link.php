<?php
class Link extends LinkCore
{
      
    /*
    * module: ets_seo
    * date: 2022-01-17 18:57:40
    * version: 2.4.2
    */
    public function getLangLink($idLang = null, Context $context = null, $idShop = null)
    {
        $langLink = parent::getLangLink($idLang, $context, $idShop);
        if (!$context) {
            $context = Context::getContext();
        }
        if (!$idLang) {
            $idLang = $context->language->id;
        }
        if(Language::isMultiLanguageActivated($idShop) && (int)Configuration::get('ETS_SEO_ENABLE_REMOVE_LANG_CODE_IN_URL') && $idLang == (int)Configuration::get('PS_LANG_DEFAULT')){
            return '';
        }
        return $langLink;
    }
    
    
    
    
    
    /*
    * module: ets_geolocation
    * date: 2024-01-28 14:02:52
    * version: 1.2.1
    */
    public function publicGetLangLink($idLang = null, Context $context = null, $idShop = null)
    {
        return $this->getLangLink($idLang, $context, $idShop);
    }
}