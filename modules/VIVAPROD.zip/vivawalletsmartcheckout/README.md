# Viva-Wallet-Smart-Checkout-for-Prestashop

## Module version guide

| PrestaShop version | Module version | PHP Version     |
|--------------------|----------------|-----------------|
| 1.6.1.x - 1.7.x    | 1.x            | 7.1 or greater  |

## Requirements

1. PHP version (check Module version guide)
2. TLS 1.2
3. curl and json extension
4. Domain must be public accessible