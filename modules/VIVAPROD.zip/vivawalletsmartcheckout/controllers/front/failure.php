<?php
/**
 * Copyright since 2007 Viva Wallet
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@vivawallet.com so we can send you a copy immediately.
 *
 * @author    Viva Wallet <support@vivawallet.com>
 * @copyright Since 2007 Viva Wallet
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

declare(strict_types=1);

if (!defined('_PS_VERSION_')) {
    exit;
}

use Vivawalletsmartcheckout\Loggers\Logger;

class VivaWalletSmartCheckoutFailureModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $language = Tools::getValue('lang');

        Logger::log(
            [
                'call' => 'failureUrl',
                'arguments' => [
                    'transactionId' => Tools::getValue('t', ''),
                    'orderCode' => Tools::getValue('s', ''),
                    'eventId' => Tools::getValue('eventId', ''),
                ],
            ],
            'vivaPayments'
        );

        $prestashopVersion = version_compare(_PS_VERSION_, '1.7', '>=') ? '1.7' : '1.6';
        $this->context->smarty->assign(
            [
                'reference' => '',
                'status' => 'failed',
                'prestashop_version' => $prestashopVersion,
            ]
        );
        if ($prestashopVersion == '1.7') {
            $this->setTemplate("module:{$this->module->name}/views/templates/front/order-confirmation-17.tpl");
        } else {
            $this->setTemplate('order-confirmation-16.tpl');
        }
    }
}
