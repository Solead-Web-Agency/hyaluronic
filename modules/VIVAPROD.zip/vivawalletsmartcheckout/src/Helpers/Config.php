<?php
/**
 * Copyright since 2007 Viva Wallet
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@vivawallet.com so we can send you a copy immediately.
 *
 * @author    Viva Wallet <support@vivawallet.com>
 * @copyright Since 2007 Viva Wallet
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Vivawalletsmartcheckout\Helpers;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Config
{
    const BASE_PATH = _PS_MODULE_DIR_ . 'vivawalletsmartcheckout/config/';

    /**
     * Get configuration value
     *
     * @param $key
     * @param null $default
     *
     * @return mixed|null
     */
    public static function get($key, $default = null)
    {
        $fileName = self::BASE_PATH . strstr($key, '.', true) . '.php';
        if (file_exists($fileName)) {
            $configurationArray = require $fileName;
            $key = \Tools::substr(strstr($key, '.'), 1);

            return General::getArrayValueByKey($configurationArray, $key, $default);
        }

        return null;
    }

    /**
     * Get value from Prestashop configuration, with given key from module configuration
     *
     * @param $key
     * @param null $default
     *
     * @return false|string
     */
    public static function getFromDatabase($key, $default = null)
    {
        return \Configuration::get(self::get($key, $default));
    }

    /**
     * Get value from request, with given key from module configuration
     *
     * @param $key
     * @param null $default
     *
     * @return false|string
     */
    public static function getFromRequest($key, $default = null)
    {
        return \Tools::getValue(self::get($key, $default));
    }
}
