{*
 * Copyright since 2007 Viva Wallet
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@vivawallet.com so we can send you a copy immediately.
 *
 * @author    Viva Wallet <support@vivawallet.com>
 * @copyright Since 2007 Viva Wallet
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 *}



<script>
  var revenue = '{$total|escape:'htmlall':'UTF-8'}'; // Total de la commande
  var transaction = '{$reference|escape:'htmlall':'UTF-8'}'; // Total de la commande

  // Pour Google Analytics
  window.dataLayer.push({
    'event': 'purchase',
    'ecommerce': {
        'purchase': {
            'actionField': {
                'revenue': revenue
            }
        }
    }
  });

  // Pour Google Ads
  window.gtag('event', 'conversion', {
      'send_to': 'AW-527878129/1HwQCIPdwokCEPGP2_sB', 
      'value': revenue,
      'currency': 'EUR',
      'transaction_id':transaction,

 });
</script>

{if $prestashop_version eq '1.7'}
    <div class="card-block">
        <div class="row">
            <div class="col-md-12">
                <h3 class="h1 card-title">
                    <i class="material-icons rtl-no-flip done">&#xE876;</i>
                    {l s='Your order is confirmed' mod='vivawalletsmartcheckout'}
                </h3>
            </div>
        </div>
    </div>
    <div class="card-block">
    {if $status == 'pending'}
        <h3>{l s='Your payment on %s is in process.' sprintf=[$shop.name] mod='vivawalletsmartcheckout'}</h3>
    {else}
        <h3>{l s='Your payment on %s is complete.' sprintf=[$shop.name] mod='vivawalletsmartcheckout'}</h3>
    {/if}
    <p>
        - {l s='Amount' mod='vivawalletsmartcheckout'} : <span
                class="price"><strong>{$total|escape:'htmlall':'UTF-8'}</strong></span>
        <br/>- {l s='Viva Wallet Smart Checkout' mod='vivawalletsmartcheckout'} {l s='Reference' mod='vivawalletsmartcheckout'} : <span
                class="reference"><strong>{$reference|escape:'html':'UTF-8'}</strong></span>
        {if $status == 'pending'}
            <br/>
            <br/>
            {l s='An email will be sent to %s when payment is completed' sprintf=[$email] mod='vivawalletsmartcheckout'}
        {else}
            <br/>
            <br/>
            {l s='An email has been sent to %s with this information.' sprintf=[$email] mod='vivawalletsmartcheckout'}
        {/if}
    </p>
    </div>
{else}
    <p class="alert alert-success">
        {if $status == 'pending'}
            {l s='Your payment on %s is in process.' sprintf=$shop_name mod='vivawalletsmartcheckout'}
        {else}
            {l s='Your payment on %s is complete.' sprintf=$shop_name mod='vivawalletsmartcheckout'}
        {/if}
    </p>
    <div class="box">
        - {l s='Amount' mod='vivawalletsmartcheckout'} : <span
                class="price"><strong>{$total|escape:'htmlall':'UTF-8'}</strong></span>
        <br/>- {l s='Viva Wallet Smart Checkout' mod='vivawalletsmartcheckout'} {l s='Reference' mod='vivawalletsmartcheckout'} : <span
                class="reference"><strong>{$reference|escape:'html':'UTF-8'}</strong></span>
        {if $status == 'pending'}
            <br/>
            <br/>
            {l s='An email will be sent when payment is completed' mod='vivawalletsmartcheckout'}
        {else}
            <br/>
            <br/>
            {l s='An email has been sent with this information.' mod='vivawalletsmartcheckout'}
        {/if}
    </div>
{/if}