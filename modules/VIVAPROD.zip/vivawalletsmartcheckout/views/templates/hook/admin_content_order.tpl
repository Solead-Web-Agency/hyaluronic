{*
 * Copyright since 2007 Viva Wallet
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@vivawallet.com so we can send you a copy immediately.
 *
 * @author    Viva Wallet <support@vivawallet.com>
 * @copyright Since 2007 Viva Wallet
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 *}
{if !empty($orderCode)}
    <div class="card panel">
        <div class="card-header">
            <h3 class="card-header-title">{l s='Viva Wallet Transactions' mod='vivawalletsmartcheckout'}</h3>
        </div>
        <div class="card-body">
            <h4 class="vivawalletsmartcheckout-section-title">{l s='Order Code' mod='vivawalletsmartcheckout'} - {$orderCode|escape:'htmlall':'UTF-8'}</h4>
            {if !empty($transactions)}
                <table class="table vivawalletsmartcheckout-transactions">
                    <thead>
                    <tr>
                        <th>{l s='Created at' mod='vivawalletsmartcheckout'}</th>
                        <th>{l s='Transaction type' mod='vivawalletsmartcheckout'}</th>
                        <th>{l s='Transaction ID' mod='vivawalletsmartcheckout'}</th>
                        <th>{l s='Amount' mod='vivawalletsmartcheckout'}</th>
                        <th colspan="2">{l s='Actions' mod='vivawalletsmartcheckout'}</th>
                    </tr>
                    </thead>
                    <tbody>
                    {foreach $transactions as $transaction}
                        <tr>
                            <td>{$transaction['transaction_date_created']|escape:'html':'UTF-8'}</td>
                            <td>{$transaction['transaction_type']|escape:'html':'UTF-8'}</td>
                            <td>{$transaction['transaction_id']|escape:'html':'UTF-8'}</td>
                            <td>{$transaction['currency']|escape:'html':'UTF-8'} {$transaction['transaction_amount']|escape:'html':'UTF-8'}</td>
                            {if $refundable_amount > 0 && $transaction['transaction_type'] eq 'payment' && $payments_number eq 1}
                                <form id="vivawalletsmartcheckout_refund_form">
                                    <td>
                                        <input type="hidden" name="vivawalletsmartcheckout_refundable_amount"
                                               value="{$refundable_amount|escape:'html':'UTF-8'}">
                                        <input type="hidden" name="vivawalletsmartcheckout_transaction_id"
                                               value="{$transaction['transaction_id']|escape:'html':'UTF-8'}">
                                        <input type="hidden" name="vivawalletsmartcheckout_transaction_date"
                                               value="{$transaction['transaction_gmt_date_created']|escape:'html':'UTF-8'}">
                                        <input type="submit" class="btn btn-sm btn-primary js-payment-details-btn"
                                               value="{l s='Refund' mod='vivawalletsmartcheckout'}"
                                               id="vivawalletsmartcheckout_refund_form_submit"/>
                                    </td>
                                    <td>
                                        <input type="number" class="form-control" size="6" min="0" step=".01"
                                               name="vivawalletsmartcheckout_requested_amount"
                                               value="{$refundable_amount|escape:'html':'UTF-8'}">
                                    </td>
                                </form>
                            {else}
                                <td></td>
                                <td></td>
                            {/if}
                        </tr>
                    {/foreach}
                    </tbody>
                </table>
                <div class="error vivawalletsmartcheckout-refund-transaction-error"></div>
            {/if}
        </div>
    </div>
{/if}
