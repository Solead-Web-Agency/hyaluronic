/**
 * Copyright since 2007 Viva Wallet
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@vivawallet.com so we can send you a copy immediately.
 *
 * @author    Viva Wallet <support@vivawallet.com>
 * @copyright Since 2007 Viva Wallet
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
$(document).ready(function() {
    const vivawalletsmartcheckout_selector_demo_mode = $('#VIVAWALLET_SMART_CHECKOUT_DEMO_MODE_on').parent();
    const vivawalletsmartcheckout_radio_button_demo_mode_on = $('#VIVAWALLET_SMART_CHECKOUT_DEMO_MODE_on');
    vivawalletsmartcheckout_radio_button_demo_mode_on.is(':checked') 
        ? vivawalletsmartcheckout_showDemoCredentialInputs() 
        : vivawalletsmartcheckout_showLiveCredentialInputs();

    vivawalletsmartcheckout_selector_demo_mode.click(function () {
        vivawalletsmartcheckout_radio_button_demo_mode_on.is(':checked') 
            ? vivawalletsmartcheckout_showDemoCredentialInputs() 
            : vivawalletsmartcheckout_showLiveCredentialInputs();
    })
});

function vivawalletsmartcheckout_showDemoCredentialInputs() {
    $('#VIVAWALLET_SMART_CHECKOUT_DEMO_CLIENT_ID').closest('div[class^="form-group"]').css('display', 'block');
    $('#VIVAWALLET_SMART_CHECKOUT_DEMO_CLIENT_SECRET').closest('div[class^="form-group"]').css('display', 'block');
    $('#VIVAWALLET_SMART_CHECKOUT_DEMO_SOURCE').closest('div[class^="form-group"]').css('display', 'block');
    $('#VIVAWALLET_SMART_CHECKOUT_LIVE_CLIENT_ID').closest('div[class^="form-group"]').css('display', 'none');
    $('#VIVAWALLET_SMART_CHECKOUT_LIVE_CLIENT_SECRET').closest('div[class^="form-group"]').css('display', 'none');
    $('#VIVAWALLET_SMART_CHECKOUT_LIVE_SOURCE').closest('div[class^="form-group"]').css('display', 'none');
}

function vivawalletsmartcheckout_showLiveCredentialInputs() {
    $('#VIVAWALLET_SMART_CHECKOUT_DEMO_CLIENT_ID').closest('div[class^="form-group"]').css('display', 'none');
    $('#VIVAWALLET_SMART_CHECKOUT_DEMO_CLIENT_SECRET').closest('div[class^="form-group"]').css('display', 'none');
    $('#VIVAWALLET_SMART_CHECKOUT_DEMO_SOURCE').closest('div[class^="form-group"]').css('display', 'none');
    $('#VIVAWALLET_SMART_CHECKOUT_LIVE_CLIENT_ID').closest('div[class^="form-group"]').css('display', 'block');
    $('#VIVAWALLET_SMART_CHECKOUT_LIVE_CLIENT_SECRET').closest('div[class^="form-group"]').css('display', 'block');
    $('#VIVAWALLET_SMART_CHECKOUT_LIVE_SOURCE').closest('div[class^="form-group"]').css('display', 'block');
}

