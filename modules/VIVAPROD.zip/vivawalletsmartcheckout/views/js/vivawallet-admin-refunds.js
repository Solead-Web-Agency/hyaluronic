/**
 * Copyright since 2007 Viva Wallet
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@vivawallet.com so we can send you a copy immediately.
 *
 * @author    Viva Wallet <support@vivawallet.com>
 * @copyright Since 2007 Viva Wallet
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
$(document).ready(function () {

    if ($('.vivawalletsmartcheckout-section-title').length) {
        $('button.partial-refund-display').hide();
        $('#desc-order-partial_refund').hide();
    }

    $('form#vivawalletsmartcheckout_refund_form').submit(function (e) {
        e.preventDefault();
        $('.vivawalletsmartcheckout-refund-transaction-error').text('').hide();

        const $submitButton = $('input#vivawalletsmartcheckout_refund_form_submit');
        const $requestedAmountInput = $('input[name=vivawalletsmartcheckout_requested_amount]');
        const $transactionIdInput = $('input[name=vivawalletsmartcheckout_transaction_id]');
        const $transactionDateInput = $('input[name=vivawalletsmartcheckout_transaction_date]');
        const $refundableAmountInput = $('input[name=vivawalletsmartcheckout_refundable_amount]');

        $submitButton.prop('disabled', true);
        $requestedAmountInput.prop('disabled', true);

        const transaction_id = $transactionIdInput.val();
        const transaction_date = $transactionDateInput.val();
        let requested_amount = vivawalletsmartcheckout_getFormattedAmount($requestedAmountInput.val());
        let refundable_amount = vivawalletsmartcheckout_getFormattedAmount($refundableAmountInput.val());
        if (!vivawalletsmartcheckout_isValidAmount(requested_amount, refundable_amount)) {
            vivawalletsmartcheckout_showError(amount_error_message);
            return false;
        }
        let is_full_refund = vivawalletsmartcheckout_isFullRefund(requested_amount, refundable_amount);
        vivawalletsmartcheckout_refundTransaction(
            requested_amount.toFixed(0),
            transaction_id,
            transaction_date,
            is_full_refund
        );
    });
});

function vivawalletsmartcheckout_refundTransaction(amount, transaction_id, transaction_date, is_full_refund) {
    $.ajax({
        type: 'POST',
        dataType: 'json',
        async: false,
        url: vivawallet_refund_url,
        data: {
            amount: amount,
            transaction_id: transaction_id,
            transaction_date: transaction_date,
            order_id: order_id,
            order_reference: order_reference,
            payment_method: payment_method,
            is_full_refund: is_full_refund
        },
        success: function (resp) {
            if (resp.error === true) {
                vivawalletsmartcheckout_showError(resp.message);
                return false;
            }
            location.reload();
        },
        error: function (err) {
            vivawalletsmartcheckout_showError(
                (typeof err.message !== 'undefined') ? err.message : general_error_message
            );
        }
    });
}

function vivawalletsmartcheckout_showError(message) {
    const $submitButton = $('input#vivawalletsmartcheckout_refund_form_submit');
    const $requestedAmountInput = $('input[name=vivawalletsmartcheckout_requested_amount]');
    $submitButton.prop('disabled', false);
    $requestedAmountInput.prop('disabled', false);
    $('.vivawalletsmartcheckout-refund-transaction-error').text(message).show();
}

function vivawalletsmartcheckout_getFormattedAmount(requested_amount) {
    requested_amount = Number.parseFloat(requested_amount);
    return requested_amount * 100;
}

function vivawalletsmartcheckout_isFullRefund(requestedAmount, refundableAmount) {
    return requestedAmount === refundableAmount;
}

function vivawalletsmartcheckout_isValidAmount(requestedAmount, refundableAmount) {
    return (requestedAmount > 0 && requestedAmount <= refundableAmount);
}
