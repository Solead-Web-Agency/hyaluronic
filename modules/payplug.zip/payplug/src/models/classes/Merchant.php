<?php
/**
 * 2013 - 2024 Payplug SAS.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0).
 * It is available through the world-wide-web at this URL:
 * https://opensource.org/licenses/osl-3.0.php
 * If you are unable to obtain it through the world-wide-web, please send an email
 * to contact@payplug.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PayPlug module to newer
 * versions in the future.
 *
 * @author    Payplug SAS
 * @copyright 2013 - 2024 Payplug SAS
 * @license   https://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *  International Registered Trademark & Property of Payplug SAS
 */

namespace PayPlug\src\models\classes;

use PayPlug\classes\DependenciesClass;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Merchant
{
    public $dependencies;

    public function __construct()
    {
        $this->dependencies = new DependenciesClass();
    }

    /**
     * @description Get client data for live and test mode
     *
     * @param string $session
     * @param string $company_id
     *
     * @return array
     */
    public function getClientData($session = '', $company_id = '')
    {
        if (!is_string($session) || empty($session)) {
            $this->dependencies
                ->getPlugin()
                ->getLogger()
                ->addLog('Merchant::getClientData - Invalid argument, $session must be a non empty string.', 'error');

            return [
                'result' => false,
                'message' => 'Wrong session given',
            ];
        }

        if (!is_string($company_id) || empty($company_id)) {
            $this->dependencies
                ->getPlugin()
                ->getLogger()
                ->addLog('Merchant::getClientData - Invalid argument, $company_id must be a non empty string.', 'error');

            return [
                'result' => false,
                'message' => 'Wrong company_id given',
            ];
        }

        $data = [];

        // Get the client id and secret for test mode
        $client_data_test = $this->dependencies
            ->getPlugin()
            ->getApiService()
            ->getClientData($session, $company_id, 'test');
        $data['test'] = $client_data_test['result']
            ? $client_data_test['data']
            : [
                'client_id' => '',
                'client_secret' => '',
            ];

        // Get the client id and secret for live mode
        $client_data_test = $this->dependencies
            ->getPlugin()
            ->getApiService()
            ->getClientData($session, $company_id, 'live');
        $data['live'] = $client_data_test['result']
            ? $client_data_test['data']
            : [
                'client_id' => '',
                'client_secret' => '',
            ];

        return [
            'result' => true,
            'data' => $data,
        ];
    }

    /**
     * @description Register client data given getted from API
     *
     * @param array $client_data
     *
     * @return bool
     */
    public function registerClientData($client_data = [])
    {
        if (!is_array($client_data) || empty($client_data)) {
            $this->dependencies
                ->getPlugin()
                ->getLogger()
                ->addLog('Merchant::registerClientData - Invalid argument, $client_data must be an array.', 'error');

            return false;
        }

        return $this->dependencies
            ->getPlugin()
            ->getConfigurationClass()
            ->set('client_data', $client_data);
    }
}
