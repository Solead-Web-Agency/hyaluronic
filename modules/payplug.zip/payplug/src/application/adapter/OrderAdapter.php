<?php
/**
 * 2013 - 2024 Payplug SAS.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0).
 * It is available through the world-wide-web at this URL:
 * https://opensource.org/licenses/osl-3.0.php
 * If you are unable to obtain it through the world-wide-web, please send an email
 * to contact@payplug.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PayPlug module to newer
 * versions in the future.
 *
 * @author    Payplug SAS
 * @copyright 2013 - 2024 Payplug SAS
 * @license   https://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *  International Registered Trademark & Property of Payplug SAS
 */

namespace PayPlug\src\application\adapter;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PayPlug\src\interfaces\OrderInterface;

class OrderAdapter implements OrderInterface
{
    public function get($idOrder = null)
    {
        if (!is_int($idOrder)) {
            $idOrder = false;
        }

        return new \Order($idOrder);
    }

    /**
     * @description Get Order for a given cart
     *
     * @param int $id_cart
     *
     * @return mixed
     */
    public function getIdByCartId($id_cart = 0)
    {
        if (method_exists('Order', 'getIdByCartId')) {
            return \Order::getIdByCartId($id_cart);
        }

        return \Order::getOrderByCartId($id_cart);
    }
}
