<?php
/**
 * Copyright since 2007 Viva Wallet
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@vivawallet.com so we can send you a copy immediately.
 *
 * @author    Viva Wallet <support@vivawallet.com>
 * @copyright Since 2007 Viva Wallet
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

declare(strict_types=1);

if (!defined('_PS_VERSION_')) {
    exit;
}

use Vivawallet\VivawalletPhp\Api\WebhookClient;
use Vivawalletsmartcheckout\Helpers\Config;
use Vivawalletsmartcheckout\Helpers\Database;
use Vivawalletsmartcheckout\Helpers\General;
use Vivawalletsmartcheckout\Helpers\Order as VivawalletsmartcheckoutOrder;
use Vivawalletsmartcheckout\Helpers\Transaction;

/**
 * Handles apm notifications
 *
 * Class VivaWalletSmartCheckoutWebhookModuleFrontController
 */
class VivaWalletSmartCheckoutWebhookModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $webhookClient = new WebhookClient($this->module->getBearerAuthentication());
            $webhookResponse = $webhookClient->getVerificationToken();
            $token = $webhookResponse->isSuccessful() && !empty($webhookResponse->getBody()->key)
                ? $webhookResponse->getBody()->key
                : '';
            echo json_encode(['key' => $token]);
            exit;
        }
    }

    public function postProcess()
    {
        parent::postProcess();
        $responseCode = 200;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $request = $this->getPostRequest();
            $environment = Tools::getValue('environment', $this->module->getEnvironment());
            if (is_object($request)
                && in_array($request->EventTypeId, config::get('app.viva_payments.webhook_events'))
                && !empty($request->EventData->OrderCode)
            ) {
                $result = Database::getSmartCheckoutOrderByCode(
                    (string) $request->EventData->OrderCode,
                    (string) $environment
                );
                if (!empty($result['cart_id'])) {
                    // Récupérer les données originales du panier
                    $cartData = \Db::getInstance()->getRow('
                        SELECT id_carrier, delivery_option 
                        FROM `'._DB_PREFIX_.'cart` 
                        WHERE id_cart = '.(int)$result['cart_id']
                    );

                    // Créer le panier avec les bonnes données
                    $cart = new Cart((int) $result['cart_id']);
                    
                    // Restaurer le transporteur original
                    if (!empty($cartData['id_carrier'])) {
                        $cart->id_carrier = (int)$cartData['id_carrier'];
                        $cart->delivery_option = $cartData['delivery_option'];
                        $cart->update();
                    }

                    $orderStateIdMapArray = [
                        'failed' => (int) Configuration::get('PS_OS_ERROR'),
                        'successful' => (int) Configuration::get(
                            Config::getFromDatabase('app.form.fields.preferred_status')
                        ),
                        'pending' => (int) Config::getFromDatabase('app.order.states.pending.field'),
                    ];
                    if (!empty($request->EventData->TransactionId)) {
                        $options = [
                            'orderCode' => $request->EventData->OrderCode,
                            'transactionId' => $request->EventData->TransactionId,
                            'environment' => $environment,
                        ];
                        $transactionResponse = Transaction::retrieveTransaction($options);
                        $transactionStatus = Transaction::getTransactionStatus($options, $transactionResponse);
                        if (
                            (
                                $transactionStatus == 'successful'
                                && $request->EventTypeId == config::get('app.viva_payments.webhook_events.success')
                            )
                            ||
                            (
                                $transactionStatus == 'failed'
                                && $request->EventTypeId == config::get('app.viva_payments.webhook_events.failure')
                            )
                        ) {
                            $transactionId = !empty($request->EventData->TransactionId)
                                ? (string) $request->EventData->TransactionId
                                : '';
                            $tries = 0;
                            $maxTries = config::get('app.viva_payments.max_webhook_tries');
                            while (!VivawalletsmartcheckoutOrder::orderExistsForCart($cart) && $tries++ < $maxTries) {
                                sleep(2); // avoid duplicates due to createOrder from successUrl
                            }
                            if (!VivawalletsmartcheckoutOrder::orderExistsForCart($cart)) {
                                if ($transactionStatus == 'successful') {
                                    $customer = new Customer($cart->id_customer);
                                    $currencyCodeArray = General::getCurrencyIsoCodeNumToIsoCodeArray();
                                    $currencyNumericCode = (string) $transactionResponse->getBody()->currencyCode;
                                    $currencyCode = $currencyCodeArray[$currencyNumericCode]
                                                    ?? (string) $result['currency'];

                                    // Calculer le montant total avec les bons frais de port
                                    $cartAmount = (float) $cart->getOrderTotal(true, Cart::BOTH);
                                    
                                    $order = VivawalletsmartcheckoutOrder::createPrestashopOrder(
                                        $cart,
                                        $cartAmount,
                                        $currencyCode,
                                        $orderStateIdMapArray[$transactionStatus],
                                        $transactionId,
                                        $customer->secure_key
                                    );
                                    unset($customer);
                                    if (!empty($order) && Validate::isLoadedObject($order)) {
                                        Database::updateSmartCheckoutOrder((int) $result['id'], (int) $order->id);
                                        Database::insertTransaction(
                                            (string) $request->EventData->OrderCode,
                                            (string) $environment,
                                            $transactionId
                                        );
                                        VivawalletsmartcheckoutOrder::processSuccessfulOrder(
                                            $order,
                                            (string) $request->EventData->OrderCode
                                        );
                                    }
                                }
                            } else {
                                $order = new Order(Order::getOrderByCartId($cart->id));
                                if (!empty($order)
                                    && Validate::isLoadedObject($order)
                                    && $transactionStatus == 'successful'
                                    && !empty($order->current_state)
                                    && $order->current_state == $orderStateIdMapArray['pending']
                                ) {
                                    Database::insertTransaction(
                                        (string) $request->EventData->OrderCode,
                                        (string) $environment,
                                        $transactionId
                                    );
                                    $prestashopVersion = version_compare(_PS_VERSION_, '1.7', '>=') ? '1.7' : '1.6';
                                    if ($prestashopVersion == '1.7') {
                                        $order->setCurrentState($orderStateIdMapArray[$transactionStatus]);
                                    } else {
                                        VivawalletsmartcheckoutOrder::setCurrentState(
                                            $order,
                                            $orderStateIdMapArray[$transactionStatus]
                                        );
                                    }
                                    $orderPayments = OrderPayment::getByOrderReference($order->reference);
                                    foreach ($orderPayments as $orderPayment) {
                                        $orderPayment->transaction_id = $transactionId;
                                        $orderPayment->update();
                                    }
                                }
                            }
                        } else {
                            $responseCode = 400;
                        }
                    }
                }
            }
            http_response_code($responseCode);
            exit;
        }
    }

    /**
     * Get post request data as an object
     *
     * @return mixed
     */
    private function getPostRequest()
    {
        return json_decode(Tools::file_get_contents('php://input'), false, 512, JSON_BIGINT_AS_STRING);
    }
}
