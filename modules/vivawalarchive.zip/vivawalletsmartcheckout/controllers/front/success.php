<?php
/**
 * Copyright since 2007 Viva Wallet
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@vivawallet.com so we can send you a copy immediately.
 *
 * @author    Viva Wallet <support@vivawallet.com>
 * @copyright Since 2007 Viva Wallet
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

declare(strict_types=1);

if (!defined('_PS_VERSION_')) {
    exit;
}

use Vivawalletsmartcheckout\Helpers\Transaction;
use Vivawalletsmartcheckout\Loggers\Logger;

class VivaWalletSmartCheckoutSuccessModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $orderCode = Tools::getValue('s');
        $environment = Tools::getValue('environment', $this->module->getEnvironment());
        $transactionId = Tools::getValue('t');
        $eventId = Tools::getValue('eventId');
        $language = Tools::getValue('lang');
        $status = '';
        $total = 0;
        $email = '';

        $prestashopVersion = version_compare(_PS_VERSION_, '1.7', '>=') ? '1.7' : '1.6';

        if (!empty($orderCode) && !empty($transactionId)) {
            $options = [
                'orderCode' => $orderCode,
                'transactionId' => $transactionId,
                'environment' => $environment,
            ];
            $transactionResponse = Transaction::retrieveTransaction($options);
            if (!empty($transactionResponse->getBody())) {
                $total = $transactionResponse->getBody()->amount;
                $email = $transactionResponse->getBody()->email;
            }
            $transactionStatus = Transaction::getTransactionStatus($options, $transactionResponse);
            $status = $transactionStatus;
        }

        Logger::log(
            [
                'call' => 'successUrl',
                'arguments' => [
                    'transactionId' => $transactionId,
                    'orderCode' => $orderCode,
                    'eventId' => $eventId,
                    'status' => $status,
                ],
            ],
            'vivaPayments',
            1
        );

        // Reset cart but preserve carrier selection
        $savedCarrierId = $this->context->cart->id_carrier;
        $savedDeliveryOption = $this->context->cart->delivery_option;

        $this->context->cart->id = null;
        $this->context->cart->gift_message = null;
        $this->context->cart->mobile_theme = null;
        $this->context->cart->date_add = null;
        $this->context->cart->secure_key = null;
        $this->context->cart->date_upd = null;
        $this->context->cart->allow_seperated_package = false;

        // Restore carrier selection
        $this->context->cart->id_carrier = $savedCarrierId;
        $this->context->cart->delivery_option = $savedDeliveryOption;

        $this->context->smarty->assign(
            [
                'reference' => $orderCode,
                'status' => $status,
                'prestashop_version' => $prestashopVersion,
                'total' => $total,
                'email' => $email,
            ]
        );
        if ($prestashopVersion == '1.7') {
            $this->setTemplate("module:{$this->module->name}/views/templates/front/order-confirmation-17.tpl");
        } else {
            $this->setTemplate('order-confirmation-16.tpl');
        }
    }
}
