<?php
class CartController extends CartControllerCore
{
    
    /*
    * module: productbundlespro
    * date: 2022-06-14 12:03:55
    * version: 2.1.9
    */
    protected function updateCart()
    {
        include_once(_PS_MODULE_DIR_ . '/productbundlespro/lib/bootstrap.php');
        $id_shop = $this->context->shop->id;
        if (PBPConfigHelper::getBundleDiscountCombinable($id_shop)) {
            parent::updateCart();
            return;
        }
        if (CartRule::isFeatureActive()) {
            if (Tools::getIsset('addDiscount') && PBPVoucherHelper::cartHasBundleVoucher($this->context->cart->id)) {
                $this->errors[] = $this->trans(
                    'The voucher is not combinable with bundle discounts',
                    array(),
                    'Shop.Notifications.Error'
                );
            }
        }
        parent::updateCart();
    }
    /*
    * module: blockproductsbycountry
    * date: 2023-03-20 10:47:56
    * version: 1.0.2
    */
    protected function processChangeProductInCart()
    {
        if (Module::isEnabled('blockproductsbycountry')) {
            if ($this->id_product) {
                $context = Context::getContext();
                if (!empty($context->country)) {
                    $country = $context->country;
                    if (!empty($country->id)) {
                        $id_country = $country->id;
                        $bpbc_module = Module::getInstanceByName('blockproductsbycountry');
                        if ($bpbc_module->isProductBlocked($this->id_product, $id_country)) {
                            $this->errors[] = Tools::displayError($bpbc_module->getBlockedText($this->id_product), !Tools::getValue('ajax'));
                            return;
                        }
                    }
                }
            }
        }
        return parent::processChangeProductInCart();
    }
}
