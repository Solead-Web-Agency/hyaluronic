<?php

class Hook extends HookCore
{
    /*
    * module: jprestaspeedpack
    * date: 2022-09-07 15:53:24
    * version: 7.9.11
    */
    public static function coreCallHook($module, $method, $params)
    {
        if (!Module::isEnabled('jprestaspeedpack') || !file_exists(_PS_MODULE_DIR_ . 'jprestaspeedpack/jprestaspeedpack.php')) {
            return parent::coreCallHook($module, $method, $params);
        }
        else {
            require_once _PS_MODULE_DIR_ . 'jprestaspeedpack/jprestaspeedpack.php';
            return Jprestaspeedpack::execHook(Jprestaspeedpack::HOOK_TYPE_MODULE, $module, $method, $params);
        }
    }
    /*
    * module: jprestaspeedpack
    * date: 2022-09-07 15:53:24
    * version: 7.9.11
    */
    public static function coreRenderWidget($module, $hook_name, $params)
    {
        if (!Module::isEnabled('jprestaspeedpack') || !file_exists(_PS_MODULE_DIR_ . 'jprestaspeedpack/jprestaspeedpack.php')) {
            return parent::coreRenderWidget($module, $hook_name, $params);
        }
        else {
            require_once _PS_MODULE_DIR_ . 'jprestaspeedpack/jprestaspeedpack.php';
            return Jprestaspeedpack::execHook(Jprestaspeedpack::HOOK_TYPE_WIDGET, $module, $hook_name, $params);
        }
    }
}
