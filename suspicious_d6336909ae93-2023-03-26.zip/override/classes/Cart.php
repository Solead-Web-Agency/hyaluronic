<?php
class Cart extends CartCore
{
    /*
    * module: sdevatos
    * date: 2022-02-03 06:27:48
    * version: 1.2.1
    */
    public function getDeliveryOption($default_country = null, $dontAutoSelectOptions = false, $use_cache = true)
    {
        return parent::getDeliveryOption($default_country, $dontAutoSelectOptions, false);
    }
    /*
    * module: blockproductsbycountry
    * date: 2023-03-20 10:47:55
    * version: 1.0.2
    */
    public function checkProductsAccess()
    {
        $return = parent::checkProductsAccess();
        $context = Context::getContext();
        if (!$return) {
            if (empty($context->controller->php_self) || $context->controller->php_self == 'order' || $context->controller->php_self == 'order-opc') {
                return $return;
            }
            if (Module::isEnabled('blockproductsbycountry')) {
                $bpbc = Module::getInstanceByName('blockproductsbycountry');
                $id_country = $context->country->id;
                if ($id_country) {
                    foreach ($this->getProducts() as $product) {
                        if ($bpbc->isProductBlocked((int)$product['id_product'], $id_country)) {
                            return $product['id_product'];
                        }
                    }
                }
            }
        }
        return $return;
    }
}
