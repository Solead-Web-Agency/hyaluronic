<?php
/**
 * Page Cache Ultimate, Page Cache standard and Speed pack are powered by Jpresta (jpresta . com)
 *
 *    @author    Jpresta
 *    @copyright Jpresta
 *    @license   You are just allowed to modify this copy for your own use. You must not redistribute it. License
 *               is permitted for one Prestashop instance only but you can install it on your test instances.
 */
class Media extends MediaCore
{
    /*
    * module: jprestaspeedpack
    * date: 2022-09-07 15:53:24
    * version: 7.9.11
    */
    public static function clearCache()
    {
        if (Module::isEnabled('jprestaspeedpack') && file_exists(_PS_MODULE_DIR_ . 'jprestaspeedpack/jprestaspeedpack.php')) {
            foreach (array(_PS_THEME_DIR_ . 'cache') as $dir) {
                if (file_exists($dir) && count(array_diff(scandir($dir), array('..', '.', 'index.php'))) > 0) {
                    Jprestaspeedpack::clearCache();
                    break;
                }
            }
        }
        if (is_callable('parent::clearCache')) {
            parent::clearCache();
        }
    }
}
