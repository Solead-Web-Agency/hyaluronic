<?php
/**
 * Page Cache Ultimate, Page Cache standard and Speed pack are powered by Jpresta (jpresta . com)
 *
 *    @author    Jpresta
 *    @copyright Jpresta
 *    @license   You are just allowed to modify this copy for your own use. You must not redistribute it. License
 *               is permitted for one Prestashop instance only but you can install it on your test instances.
 */
class Module extends ModuleCore
{
    /*
    * module: jprestaspeedpack
    * date: 2022-09-07 15:53:25
    * version: 7.9.11
    */
    protected function getCacheId($name = null)
    {
        $cacheId = parent::getCacheId($name);
        if (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'image/webp') !== false) {
            $cacheId .= '|webp';
        }
        return $cacheId;
    }
}
