<?php

class BridgeOverride extends Bridge {
    public function hookActionFrontControllerSetMedia()
    {
        $controller = Context::getContext()->controller;
        if (strpos($controller->page_name, 'checkout') !== false) {
            Media::addJsDef([
                'bridge' => [
                    'translations' => [
                        'back' => $this->l('Back', 'commonhook'),
                        'pay' => $this->l('Pay via Bridge', 'commonhook'),
                        'choose_bank' => $this->l('Choose my bank', 'commonhook'),
                        'search_bank' => $this->l('Search a bank', 'commonhook'),
                        'no_results_found' => $this->l('No results to display', 'commonhook'),
                    ],
                    'bank_list_url' => Context::getContext()->link->getModuleLink($this->name, 'banklist'),
                ],
            ]);
            $controller->registerJavascript(
                'bridge-vue-main',
                'modules/' . $this->name . '/views/js/front/front.js',
                [
                    'priority' => 500,
                ]
            );
            $controller->registerStylesheet(
                'bridge-vue-main-css',
                'modules/' . $this->name . '/views/css/front.css',
                [
                    'priority' => 500,
                ]
            );
        }
    }
}